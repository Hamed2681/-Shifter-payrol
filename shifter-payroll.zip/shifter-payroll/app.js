/* ============================================================
   Shifter Payroll — Web App
   Self-contained scheduler + payroll calculator
   ============================================================ */

'use strict';

const STORAGE_KEY = 'shifter_payroll_v1';
const SEQ_KEY = 'shifter_seq';

/* ========== Storage helpers ========== */
function _getItem(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw !== null ? JSON.parse(raw) : fallback;
  } catch (e) { return fallback; }
}
function _setItem(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); return true; }
  catch (e) { return false; }
}
function _removeItem(key) {
  try { localStorage.removeItem(key); return true; }
  catch (e) { return false; }
}

function nextSeq() {
  const n = (_getItem(SEQ_KEY, 0) || 0) + 1;
  _setItem(SEQ_KEY, n);
  return n;
}

/* ========== Toast ========== */
let toastTimer;
function toast(msg, type = '') {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.className = 'toast show ' + type;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.className = 'toast'; }, 2200);
}

/* ========== In-app dialogs ========== */
function pgConfirm(message, { okOnly = false } = {}) {
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.className = 'pg-confirm-overlay';
    overlay.innerHTML = `
      <div class="pg-confirm-box">
        <p>${escapeHtml(message)}</p>
        <div class="pg-confirm-actions">
          ${okOnly ? '' : '<button class="primary-btn outline" data-act="cancel">إلغاء</button>'}
          <button class="primary-btn" data-act="ok">حسناً</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    const cleanup = result => { overlay.remove(); resolve(result); };
    overlay.querySelector('[data-act="ok"]').addEventListener('click', () => cleanup(true));
    const cancelBtn = overlay.querySelector('[data-act="cancel"]');
    if (cancelBtn) cancelBtn.addEventListener('click', () => cleanup(false));
    overlay.addEventListener('click', e => { if (e.target === overlay && !okOnly) cleanup(false); });
  });
}

function pgPrompt(message, defaultValue = '') {
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.className = 'pg-confirm-overlay';
    overlay.innerHTML = `
      <div class="pg-confirm-box">
        <p>${escapeHtml(message)}</p>
        <input type="text" class="pg-prompt-input" id="pgPromptInput" value="${escapeHtml(defaultValue)}" />
        <div class="pg-confirm-actions">
          <button class="primary-btn outline" data-act="cancel">إلغاء</button>
          <button class="primary-btn" data-act="ok">حفظ</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    const input = overlay.querySelector('#pgPromptInput');
    input.focus(); input.select();
    const cleanup = result => { overlay.remove(); resolve(result); };
    overlay.querySelector('[data-act="ok"]').addEventListener('click', () => cleanup(input.value.trim()));
    overlay.querySelector('[data-act="cancel"]').addEventListener('click', () => cleanup(null));
    input.addEventListener('keydown', e => { if (e.key === 'Enter') cleanup(input.value.trim()); });
    overlay.addEventListener('click', e => { if (e.target === overlay) cleanup(null); });
  });
}

function pgAdditionForm(existing) {
  return new Promise(resolve => {
    const isSpecial = !!(existing && existing.special);
    const overlay = document.createElement('div');
    overlay.className = 'pg-confirm-overlay';
    overlay.innerHTML = `
      <div class="pg-confirm-box">
        <p>${existing ? 'تعديل البند' : 'إضافة بند جديد للإضافات'}</p>
        <input type="text" class="pg-prompt-input" id="addFormLabel" placeholder="اسم البند" value="${escapeHtml(existing?.label || '')}" />
        <label class="pg-checkbox-row">
          <input type="checkbox" id="addFormPerShift" ${existing?.mode === 'perShift' ? 'checked' : ''} ${isSpecial ? 'disabled' : ''} />
          <span>إضافة في الوردية (تُحسب تلقائياً حسب أيام الحضور × قيمة الوردية)${isSpecial ? ' — ثابت' : ''}</span>
        </label>
        <div class="pg-confirm-actions">
          <button class="primary-btn outline" data-act="cancel">إلغاء</button>
          <button class="primary-btn" data-act="ok">حفظ</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    const labelInput = overlay.querySelector('#addFormLabel');
    labelInput.focus(); labelInput.select();
    const perShiftInput = overlay.querySelector('#addFormPerShift');
    const cleanup = result => { overlay.remove(); resolve(result); };
    overlay.querySelector('[data-act="ok"]').addEventListener('click', () => {
      const label = labelInput.value.trim();
      if (!label) { labelInput.focus(); return; }
      const mode = isSpecial ? existing.mode : (perShiftInput.checked ? 'perShift' : 'manual');
      cleanup({ label, mode });
    });
    overlay.querySelector('[data-act="cancel"]').addEventListener('click', () => cleanup(null));
    labelInput.addEventListener('keydown', e => { if (e.key === 'Enter') overlay.querySelector('[data-act="ok"]').click(); });
    overlay.addEventListener('click', e => { if (e.target === overlay) cleanup(null); });
  });
}

/* ========== Default data ========== */
const DEFAULT_SHIFTS = [
  { id: 's1', name: 'اول',   abbr: '1',   bg: '#f5f5f5', fg: '#1a1a1a', size: 36, start: '08:00', end: '16:00', hours: 8, dayIncome: 253, overtimeRate: 0, mealAllowance: 0, shiftAllowance: 0, currency: 'ج.م' },
  { id: 's2', name: 'تانية', abbr: '2',   bg: '#9a9a9a', fg: '#fff700', size: 36, start: '16:00', end: '00:00', hours: 8, dayIncome: 263, overtimeRate: 0, mealAllowance: 0, shiftAllowance: 0, currency: 'ج.م' },
  { id: 's3', name: 'تالتة', abbr: '3',   bg: '#2c2c2c', fg: '#ffffff', size: 36, start: '00:00', end: '08:00', hours: 8, dayIncome: 263, overtimeRate: 0, mealAllowance: 0, shiftAllowance: 0, currency: 'ج.م' },
  { id: 'sBd', name: 'بدل عطلة', abbr: 'ب عطلة', bg: '#b8d8e8', fg: '#0a3a52', size: 22, start: '08:00', end: '16:00', hours: 8, dayIncome: 213, overtimeRate: 0, mealAllowance: 0, shiftAllowance: 0, currency: 'ج.م' },
  { id: 'sR',  name: 'راحة',    abbr: 'R',   bg: '#1a1a1a', fg: '#7a4ad6', size: 24, start: '00:00', end: '00:00', hours: 0, dayIncome: 0, overtimeRate: 0, mealAllowance: 0, shiftAllowance: 0, currency: 'ج.م' },
  { id: 'sH',  name: 'اعتيادي', abbr: 'اعتيادي', bg: '#c5e0c0', fg: '#1a1a1a', size: 18, start: '08:00', end: '16:00', hours: 8, dayIncome: 213, overtimeRate: 0, mealAllowance: 0, shiftAllowance: 0, currency: 'ج.م', isAnnualLeave: true },
  { id: 'sAbs', name: 'غياب', abbr: 'غ', bg: '#7a0a0a', fg: '#ffffff', size: 36, start: '00:00', end: '00:00', hours: 0, dayIncome: 0, overtimeRate: 0, mealAllowance: 0, shiftAllowance: 0, currency: 'ج.م', isAbsence: true },
];

const PALETTE = [
  '#f5f5f5','#9a9a9a','#2c2c2c','#1a1a1a','#b8d8e8','#c5e0c0',
  '#d4a017','#e85a4f','#7a4ad6','#2bd4a4','#0a3a52','#fff700'
];

const MONTHS = ['JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE',
                'JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER'];
const WEEKDAYS = ['SAT','SUN','MON','TUE','WED','THU','FRI'];
const JS_DAY_NAMES = ['SUN','MON','TUE','WED','THU','FRI','SAT'];
const WEEK_START_INDEX = { sat: 6, sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5 };

/* ========== App state ========== */
const state = {
  shifts: [],
  schedule: {},
  view: 'month',
  current: { year: 2026, month: 6 },
  summaryMode: 'month',
  range: { from: null, to: null },
  payRange: { from: null, to: null, overtimeHours: 0, manualAdditions: {} },
  editingShift: null,
  selectedBg: '#f5f5f5',
  selectedFg: '#1a1a1a',
  paintMode: null,
  paintBarCollapsed: false,
  settings: {
    numeralType: 'ar', font: 'Cairo', calendarView: 'grid', weekStart: 'sat', holidayMode: 1
  },
  additionTypes: [
    { id: 'shiftAllowance', label: 'بدل وردية', mode: 'perShift', enabled: true, special: 'shiftAllowance' },
    { id: 'mealAllowance',   label: 'بدل وجبة',   mode: 'perShift', enabled: true, special: 'mealAllowance' },
    { id: 'overtime',        label: 'إضافي',      mode: 'manual',   enabled: true, special: 'overtime' },
    { id: 'incentives',      label: 'حوافز',      mode: 'manual',   enabled: true, special: null },
    { id: 'profits',         label: 'أرباح',      mode: 'manual',   enabled: true, special: null },
  ],
  companies: ['شركة cliopatra', 'شركة ثانية'],
  currentCompanyIndex: 0,
  leaveBalance: { previous: 0, accrued: 21 },
  leaveLog: [],
  holidays: [],
  absenceSettings: {
    absenceDayValue: 0,   // قيمة خصم يوم الغياب (تُخصم من الراتب)
    penaltyDayValue: 0,   // قيمة يوم الجزاء (يوم كامل من الراتب)
    autoApplyToPayroll: true,  // إضافة الخصم للمرتب تلقائياً
  },
  deductionTypes: [
    { id: 'd1', label: 'جزاءات/غياب',      unit: 'amount' },
    { id: 'd2', label: 'خصم تأخير',        unit: 'hours'  },
    { id: 'd3', label: 'خصومات أخرى',      unit: 'amount' },
  ],
};

let yearYear = 2026;

/* ========== Load / Save ========== */
function load() {
  try {
    const data = _getItem(STORAGE_KEY, null);
    if (data) {
      state.shifts = data.shifts || [];
      state.shifts.forEach(s => {
        if (s.isAnnualLeave === undefined) s.isAnnualLeave = (s.id === 'sH' || s.name === 'اعتيادي');
        if (s.isAbsence === undefined) s.isAbsence = (s.name === 'غياب');
      });
      state.schedule = data.schedule || {};
      state.settings = Object.assign({ numeralType: 'ar', font: 'Cairo', calendarView: 'grid', weekStart: 'sat', holidayMode: '1_1' }, data.settings || {});
      // Migrate old numeric holidayMode (1 or 2) to the new "incomeDays_leaveDays" format
      if (state.settings.holidayMode === undefined || state.settings.holidayMode === null || !String(state.settings.holidayMode).includes('_')) {
        const old = +state.settings.holidayMode || 1;
        state.settings.holidayMode = old === 2 ? '2_2' : '1_1';
      }
      if (Array.isArray(data.additionTypes) && data.additionTypes.length) {
        state.additionTypes = data.additionTypes;
      }
      if (Array.isArray(data.deductionTypes) && data.deductionTypes.length) {
        state.deductionTypes = data.deductionTypes;
      }
      if (data.range && data.range.from && data.range.to) state.range = data.range;
      if (data.payRange && data.payRange.from && data.payRange.to) {
        state.payRange = Object.assign({ overtimeHours: 0, manualAdditions: {} }, data.payRange);
        if (data.payRange.incentives !== undefined && state.payRange.manualAdditions.incentives === undefined) {
          state.payRange.manualAdditions.incentives = +data.payRange.incentives || 0;
        }
        if (data.payRange.profits !== undefined && state.payRange.manualAdditions.profits === undefined) {
          state.payRange.manualAdditions.profits = +data.payRange.profits || 0;
        }
      }
      if (Array.isArray(data.companies) && data.companies.length) state.companies = data.companies;
      if (Number.isInteger(data.currentCompanyIndex)) state.currentCompanyIndex = data.currentCompanyIndex;
      state.leaveBalance = Object.assign({ previous: 0, accrued: 21 }, data.leaveBalance || {});
      state.leaveLog = Array.isArray(data.leaveLog) ? data.leaveLog : [];
      state.holidays = Array.isArray(data.holidays) ? data.holidays : [];
      if (data.absenceSettings) {
        state.absenceSettings = Object.assign({ absenceDayValue: 0, penaltyDayValue: 0, autoApplyToPayroll: true }, data.absenceSettings);
      }
    } else {
      state.shifts = DEFAULT_SHIFTS.map(s => ({ ...s }));
      state.schedule = {};
      save();
    }
  } catch (e) {
    state.shifts = []; state.schedule = {};
  }
  applyFont();
}

function save() {
  _setItem(STORAGE_KEY, {
    shifts: state.shifts, schedule: state.schedule, settings: state.settings,
    additionTypes: state.additionTypes, deductionTypes: state.deductionTypes,
    range: state.range, payRange: state.payRange,
    companies: state.companies, currentCompanyIndex: state.currentCompanyIndex,
    leaveBalance: state.leaveBalance, leaveLog: state.leaveLog, holidays: state.holidays,
    absenceSettings: state.absenceSettings
  });
}

function applyFont() {
  const f = state.settings.font || 'Cairo';
  document.body.style.fontFamily = `'${f}', 'Cairo', 'Segoe UI', Tahoma, Arial, sans-serif`;
}

/* ========== Helpers ========== */
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

const AR_DIGITS = { '0':'٠','1':'١','2':'٢','3':'٣','4':'٤','5':'٥','6':'٦','7':'٧','8':'٨','9':'٩' };
function arDigits(v) {
  if (state.settings && state.settings.numeralType === 'en') return String(v);
  return String(v).replace(/[0-9]/g, d => AR_DIGITS[d]);
}

function pad(n) { return n < 10 ? '0' + n : '' + n; }
function dateKey(y, m, d) { return `${y}-${pad(m+1)}-${pad(d)}`; }

function getWeekStart() { return WEEK_START_INDEX[state.settings.weekStart] ?? 6; }
function weekdayCol(jsDay) {
  const first = getWeekStart();
  return (jsDay - first + 7) % 7;
}
function getWeekdayLabels() {
  const first = getWeekStart();
  const labels = [];
  for (let col = 0; col < 7; col++) {
    const jsDay = (first + col) % 7;
    labels.push(JS_DAY_NAMES[jsDay]);
  }
  return labels;
}
function renderWeekdaysHeader() {
  const row = document.getElementById('weekdaysRow');
  if (!row) return;
  row.innerHTML = getWeekdayLabels().map(l => `<span>${l}</span>`).join('');
}
function formatDateDisplay(iso) {
  if (!iso) return '—';
  const [y, m, d] = iso.split('-');
  return arDigits(`${d}/${m}/${y}`);
}

/* ============================================================
   Absence penalty calculator
   Progressive scale (per consecutive absence spell, reset after 6 months):
     day 1 -> 0.25
     day 2 -> 0.5
     day 3 -> 1
     day 4 -> 2
     day 5 -> 3
     day 6+ -> 5 each
   ============================================================ */
const PENALTY_SCALE = [0.25, 0.5, 1, 2, 3]; // index 0..4, day 6+ uses index 4 (5)
const PENALTY_DAY6_PLUS = 5;
const RESET_MONTHS = 6;

function penaltyForDay(consecutiveIndex) {
  // consecutiveIndex is 0-based: 0 = first day of the spell
  if (consecutiveIndex < PENALTY_SCALE.length) return PENALTY_SCALE[consecutiveIndex];
  return PENALTY_DAY6_PLUS;
}

function monthsBetween(d1, d2) {
  return (d2.getFullYear() - d1.getFullYear()) * 12 + (d2.getMonth() - d1.getMonth());
}

/**
 * Group absence dates into "spells" (consecutive runs) and compute penalty.
 * A new spell starts when:
 *  - the previous absence was > 1 day ago (gap), OR
 *  - the previous absence was >= 6 months ago (RESET_MONTHS)
 * Returns:
 *   { spells: [{ start, end, days, penaltyDays, dates:[] }], totalDays, totalPenaltyDays }
 */
function computeAbsencePenalty(dates) {
  if (!dates || dates.length === 0) {
    return { spells: [], totalDays: 0, totalPenaltyDays: 0 };
  }
  // dates must be sorted ascending (ISO strings)
  const sorted = [...dates].sort();
  const spells = [];
  let current = { start: sorted[0], end: sorted[0], days: 1, penaltyDays: penaltyForDay(0), dates: [sorted[0]] };

  for (let i = 1; i < sorted.length; i++) {
    const prev = new Date(sorted[i - 1] + 'T00:00:00');
    const cur = new Date(sorted[i] + 'T00:00:00');
    const dayDiff = Math.round((cur - prev) / 86400000);
    const monthGap = monthsBetween(prev, cur);

    // same spell only if exactly the next day AND we are within the same penalty count
    if (dayDiff === 1 && monthGap < RESET_MONTHS) {
      current.days += 1;
      current.end = sorted[i];
      current.dates.push(sorted[i]);
      current.penaltyDays += penaltyForDay(current.days - 1);
    } else {
      spells.push(current);
      current = { start: sorted[i], end: sorted[i], days: 1, penaltyDays: penaltyForDay(0), dates: [sorted[i]] };
    }
  }
  spells.push(current);
  const totalDays = spells.reduce((s, x) => s + x.days, 0);
  const totalPenaltyDays = spells.reduce((s, x) => s + x.penaltyDays, 0);
  return { spells, totalDays, totalPenaltyDays };
}

/* ========== Tabs ========== */
function switchTab(tab) {
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById('view-' + tab).classList.add('active');
  state.view = tab;
  document.querySelector('main').classList.toggle('no-scroll', tab === 'month');
  if (tab === 'year') renderYear();
  if (tab === 'summary') { initSummaryRangeDefaults(); renderSummary(); }
  if (tab === 'payroll') initPayroll();
}

document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});

/* ========== Month view ========== */
function updateStaticLabels() {
  document.getElementById('yearTab').textContent = arDigits(state.current.year);
  if (state.summaryMode !== 'range') {
    document.getElementById('periodLabel').textContent = arDigits(
      state.summaryMode === 'year' ? yearYear : `${MONTHS[state.current.month]} ${state.current.year}`
    );
  }
}

function fitLabelText(el, minSize = 8) {
  let size = parseFloat(getComputedStyle(el).fontSize) || 22;
  let guard = 40;
  while (guard-- > 0 && size > minSize &&
         (el.scrollWidth > el.clientWidth + 1 || el.scrollHeight > el.clientHeight + 1)) {
    size -= 1;
    el.style.fontSize = size + 'px';
  }
}
function fitAllDayLabels() {
  document.querySelectorAll('#calendar .day .label').forEach(el => fitLabelText(el));
}

function applyMonthFrame(startDay, daysInMonth) {
  const cells = [...document.querySelectorAll('#calendar .day')];
  const total = cells.length;
  const cols = 7;
  const isCurrent = idx => idx >= startDay && idx < startDay + daysInMonth;
  const addEdge = (cell, side) => {
    const bar = document.createElement('div');
    bar.className = 'frame-edge frame-edge-' + side;
    cell.appendChild(bar);
  };
  cells.forEach((cell, idx) => {
    cell.querySelectorAll('.frame-edge').forEach(e => e.remove());
    if (!isCurrent(idx)) return;
    const col = idx % cols;
    if (idx - cols < 0 || !isCurrent(idx - cols)) addEdge(cell, 'top');
    if (idx + cols >= total || !isCurrent(idx + cols)) addEdge(cell, 'bottom');
    if (col === 0 || !isCurrent(idx - 1)) addEdge(cell, 'right');
    if (col === cols - 1 || !isCurrent(idx + 1)) addEdge(cell, 'left');
  });
}

function renderEmptyState() {
  const isList = state.settings.calendarView === 'list';
  const emptyHtml = `
    <div class="empty-state">
      <div class="icon">📅</div>
      <h3>لا يوجد شيفتات</h3>
      <p>ابدأ بإضافة الشيفتات الخاصة بك</p>
      <button id="emptyStateAddBtn">➕ إضافة شيفت جديد</button>
    </div>`;
  if (isList) {
    document.getElementById('calendarList').innerHTML = emptyHtml;
    document.getElementById('calendar').innerHTML = '';
  } else {
    document.getElementById('calendar').innerHTML = `<div style="grid-column: 1 / -1;">${emptyHtml}</div>`;
    document.getElementById('calendarList').innerHTML = '';
  }
  const btn = document.getElementById('emptyStateAddBtn');
  if (btn) btn.addEventListener('click', () => { openShiftsModal(); setTimeout(() => document.getElementById('createShift').click(), 100); });
  updateStaticLabels();
}

function renderMonth() {
  const { year, month } = state.current;
  document.getElementById('monthTitle').textContent = arDigits(`${MONTHS[month]} ${year}`);
  const isList = state.settings.calendarView === 'list';
  document.getElementById('view-month').classList.toggle('list-mode', isList);

  if (state.shifts.length === 0) {
    renderEmptyState();
    return;
  }

  if (isList) {
    renderMonthList(year, month);
    renderPaintBar();
    updateStaticLabels();
    return;
  }

  const first = new Date(year, month, 1);
  const startDay = weekdayCol(first.getDay());
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const prevDays = new Date(year, month, 0).getDate();

  const cal = document.getElementById('calendar');
  cal.innerHTML = '';

  for (let i = startDay - 1; i >= 0; i--) cal.appendChild(makeDayCell(prevDays - i, year, month - 1, true));
  for (let d = 1; d <= daysInMonth; d++) cal.appendChild(makeDayCell(d, year, month, false));
  const total = startDay + daysInMonth;
  const next = (7 - (total % 7)) % 7;
  for (let i = 1; i <= next; i++) cal.appendChild(makeDayCell(i, year, month + 1, true));

  renderPaintBar();
  fitAllDayLabels();
  updateStaticLabels();
  applyMonthFrame(startDay, daysInMonth);
}

function makeDayCell(d, year, month, other) {
  const cell = document.createElement('div');
  cell.className = 'day' + (other ? ' other' : '');
  const k = dateKey(year, month, d);
  const shiftId = state.schedule[k];
  const shift = state.shifts.find(s => s.id === shiftId);

  const top = document.createElement('div');
  top.className = 'num-top';
  top.textContent = arDigits(d);
  cell.appendChild(top);

  if (shift) {
    cell.style.background = shift.bg;
    const lbl = document.createElement('div');
    lbl.className = 'label';
    lbl.style.color = shift.fg;
    lbl.style.fontSize = (shift.size || 36) + 'px';
    lbl.textContent = arDigits(shift.abbr);
    cell.appendChild(lbl);
  }
  cell.addEventListener('click', () => handleDayClick(k));
  return cell;
}

function renderMonthList(year, month) {
  const listEl = document.getElementById('calendarList');
  listEl.innerHTML = '';
  const WD = getWeekdayLabels();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  for (let d = 1; d <= daysInMonth; d++) {
    const k = dateKey(year, month, d);
    const wdIndex = weekdayCol(new Date(year, month, d).getDay());
    const shiftId = state.schedule[k];
    const shift = state.shifts.find(s => s.id === shiftId);

    const row = document.createElement('div');
    row.className = 'day-row';
    const dateBox = document.createElement('div');
    dateBox.className = 'dr-date';
    const num = document.createElement('span'); num.className = 'dr-num'; num.textContent = arDigits(d);
    const wd = document.createElement('span'); wd.className = 'dr-wd'; wd.textContent = WD[wdIndex];
    dateBox.appendChild(num); dateBox.appendChild(wd);
    row.appendChild(dateBox);

    if (shift) {
      const chip = document.createElement('div');
      chip.className = 'dr-shift';
      chip.style.background = shift.bg;
      chip.style.color = shift.fg;
      chip.textContent = arDigits(shift.abbr) + (shift.name ? ' — ' + shift.name : '');
      row.appendChild(chip);
    } else {
      const empty = document.createElement('div');
      empty.className = 'dr-empty';
      empty.textContent = '—';
      row.appendChild(empty);
    }
    row.addEventListener('click', () => handleDayClick(k));
    listEl.appendChild(row);
  }
}

function handleDayClick(k) {
  if (state.paintMode !== null) {
    if (state.paintMode === '') delete state.schedule[k];
    else state.schedule[k] = state.paintMode;
    save();
    renderMonth();
  } else {
    openShiftsModal();
  }
}

document.getElementById('prevMonth').addEventListener('click', () => {
  state.current.month--;
  if (state.current.month < 0) { state.current.month = 11; state.current.year--; }
  renderMonth();
});
document.getElementById('nextMonth').addEventListener('click', () => {
  state.current.month++;
  if (state.current.month > 11) { state.current.month = 0; state.current.year++; }
  renderMonth();
});

/* ========== Paint bar ========== */
function renderPaintBar() {
  const bar = document.getElementById('paintBar');
  const scroll = document.getElementById('paintScroll');
  bar.classList.toggle('collapsed', !!state.paintBarCollapsed);
  const toggleBtn = document.getElementById('paintToggle');
  if (toggleBtn) {
    toggleBtn.textContent = state.paintBarCollapsed ? '⌄' : '⌃';
    toggleBtn.title = state.paintBarCollapsed ? 'إظهار الورديات' : 'إخفاء الورديات';
  }
  scroll.innerHTML = '';

  state.shifts.forEach(s => {
    const b = document.createElement('button');
    b.className = 'paint-btn';
    b.dataset.shift = s.id;
    b.style.background = s.bg;
    b.style.color = s.fg;
    b.textContent = arDigits(s.abbr);
    if (state.paintMode === s.id) b.classList.add('active');
    b.addEventListener('click', () => { state.paintMode = s.id; renderPaintBar(); });
    scroll.appendChild(b);
  });

  const erase = bar.querySelector('.erase');
  erase.classList.toggle('active', state.paintMode === '');
  if (!erase.dataset.bound) {
    erase.dataset.bound = '1';
    erase.addEventListener('click', () => { state.paintMode = ''; renderPaintBar(); });
  }
}

document.getElementById('paintToggle').addEventListener('click', () => {
  state.paintMode = null;
  state.paintBarCollapsed = !state.paintBarCollapsed;
  renderPaintBar();
});

/* ========== Shifts modal ========== */
function openShiftsModal() {
  document.getElementById('shiftsModal').classList.add('open');
  renderShiftsList();
}
document.getElementById('logoBtn').addEventListener('click', () => openShiftsModal());
document.getElementById('closeShifts').addEventListener('click', () => {
  document.getElementById('shiftsModal').classList.remove('open');
});
document.getElementById('shiftsModal').addEventListener('click', e => {
  if (e.target.id === 'shiftsModal') e.target.classList.remove('open');
});

function chipFontSize(abbr) {
  const len = (abbr || '').length;
  if (len <= 2) return 28;
  if (len <= 4) return 20;
  if (len <= 6) return 15;
  if (len <= 9) return 12;
  return 10;
}

function renderShiftsList() {
  const list = document.getElementById('shiftsList');
  list.innerHTML = '';
  if (state.shifts.length === 0) {
    list.innerHTML = '<div class="mini-list-empty">لا يوجد شيفتات بعد — أنشئ واحداً جديداً</div>';
    return;
  }
  state.shifts.forEach((s, idx) => {
    const row = document.createElement('div');
    row.className = 'shift-item';
    const abbrText = arDigits(s.abbr);
    row.innerHTML = `
      <div class="chip" style="background:${s.bg};color:${s.fg};font-size:${chipFontSize(s.abbr)}px">${escapeHtml(abbrText)}</div>
      <div class="info">
        <div class="nm">${escapeHtml(s.name)}</div>
        <div class="sub">(${arDigits(pad(s.start))} - ${arDigits(pad(s.end))})</div>
      </div>
      <div class="reorder-btns">
        <button type="button" class="move-up" data-id="${s.id}" ${idx === 0 ? 'disabled' : ''} title="لأعلى">▲</button>
        <button type="button" class="move-down" data-id="${s.id}" ${idx === state.shifts.length - 1 ? 'disabled' : ''} title="لأسفل">▼</button>
      </div>`;
    row.addEventListener('click', e => { if (!e.target.closest('.reorder-btns')) openShiftConfig(s); });
    list.appendChild(row);
  });
  list.querySelectorAll('.move-up').forEach(btn => btn.addEventListener('click', e => { e.stopPropagation(); moveShift(btn.dataset.id, -1); }));
  list.querySelectorAll('.move-down').forEach(btn => btn.addEventListener('click', e => { e.stopPropagation(); moveShift(btn.dataset.id, 1); }));
}

function moveShift(id, dir) {
  const idx = state.shifts.findIndex(s => s.id === id);
  const newIdx = idx + dir;
  if (idx === -1 || newIdx < 0 || newIdx >= state.shifts.length) return;
  const [item] = state.shifts.splice(idx, 1);
  state.shifts.splice(newIdx, 0, item);
  save(); renderShiftsList(); renderPaintBar();
}

document.getElementById('createShift').addEventListener('click', () => {
  const s = {
    id: 'shf' + nextSeq(),
    name: 'شيفت جديد', abbr: 'N', bg: '#9a9a9a', fg: '#ffffff', size: 36,
    start: '08:00', end: '16:00', hours: 8, dayIncome: 0, overtimeRate: 0,
    mealAllowance: 0, shiftAllowance: 0, currency: 'ج.م'
  };
  openShiftConfig(s);
});

document.getElementById('importShifts').addEventListener('click', () => document.getElementById('importFile').click());
document.getElementById('importFile').addEventListener('change', e => {
  const f = e.target.files[0];
  if (!f) return;
  const r = new FileReader();
  r.onload = ev => {
    try {
      const data = JSON.parse(ev.target.result);
      if (Array.isArray(data.shifts)) {
        const existingCount = state.shifts.length;
        const newShifts = data.shifts.map(s => ({ ...s, id: 'shf' + nextSeq() }));
        state.shifts = state.shifts.concat(newShifts);
        save();
        renderShiftsList(); renderMonth();
        toast(`تم استيراد ${newShifts.length} شيفت (المجموع: ${state.shifts.length})`, 'success');
      } else { toast('الملف لا يحتوي على شيفتات', 'error'); }
    } catch (err) { toast('ملف JSON غير صالح', 'error'); }
    e.target.value = '';
  };
  r.readAsText(f);
});

/* ========== Shift config ========== */
function openShiftConfig(shift) {
  state.editingShift = { ...shift };
  fillConfigForm();
  document.getElementById('shiftConfigModal').classList.add('open');
  document.querySelectorAll('.ct-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.ct-panel').forEach(p => p.classList.remove('active'));
  document.querySelector('.ct-tab[data-ct="appearance"]').classList.add('active');
  document.querySelector('.ct-panel[data-ct="appearance"]').classList.add('active');
}

function fillConfigForm() {
  const s = state.editingShift;
  document.getElementById('shiftName').value = s.name;
  document.getElementById('shiftPreview').textContent = arDigits(s.abbr);
  document.getElementById('shiftPreview').style.background = s.bg;
  document.getElementById('shiftPreview').style.color = s.fg;
  document.getElementById('shiftPreview').style.fontSize = (s.size || 36) + 'px';
  document.getElementById('shiftAbbr').value = s.abbr;
  document.getElementById('textSize').value = s.size;
  document.getElementById('sizeVal').textContent = arDigits(s.size);
  document.getElementById('startTime').value = s.start;
  document.getElementById('endTime').value = s.end;
  document.getElementById('hours').value = s.hours;
  document.getElementById('currency').value = s.currency || 'ج.م';
  document.getElementById('dayIncome').value = s.dayIncome || 0;
  document.getElementById('overtimeRate').value = s.overtimeRate || 0;
  document.getElementById('mealAllowance').value = s.mealAllowance || 0;
  document.getElementById('shiftAllowance').value = s.shiftAllowance || 0;
  document.getElementById('isAnnualLeave').checked = !!s.isAnnualLeave;
  document.getElementById('isAbsence').checked = !!s.isAbsence;
  renderCustomAdditionFields();
  state.selectedBg = s.bg;
  state.selectedFg = s.fg;
  buildSwatches('bgSwatches', s.bg, c => { state.selectedBg = c; updatePreview(); });
  buildSwatches('txtSwatches', s.fg, c => { state.selectedFg = c; updatePreview(); });
  updateHourlyRate();
}

function renderCustomAdditionFields() {
  const container = document.getElementById('customAdditionFields');
  if (!container) return;
  const s = state.editingShift;
  const customPerShift = state.additionTypes.filter(a => a.mode === 'perShift' && !a.special);
  container.innerHTML = customPerShift.map(a => `
    <div class="field">
      <label>➕ ${escapeHtml(a.label)} / يوم</label>
      <input type="number" class="custom-addition-input" data-id="${a.id}"
             value="${(s && s.customAdditions && s.customAdditions[a.id]) || 0}" step="0.01" />
    </div>`).join('');
}

function buildSwatches(id, current, onPick) {
  const el = document.getElementById(id);
  el.innerHTML = '';
  PALETTE.forEach(c => {
    const sw = document.createElement('div');
    sw.className = 'swatch' + (c === current ? ' selected' : '');
    sw.style.background = c;
    sw.addEventListener('click', () => {
      el.querySelectorAll('.swatch').forEach(x => x.classList.remove('selected'));
      sw.classList.add('selected');
      onPick(c);
    });
    el.appendChild(sw);
  });
}

function updatePreview() {
  const p = document.getElementById('shiftPreview');
  p.style.background = state.selectedBg;
  p.style.color = state.selectedFg;
}
function updateHourlyRate() {
  const hours = +document.getElementById('hours').value || 0;
  const income = +document.getElementById('dayIncome').value || 0;
  const rate = hours > 0 ? (income / hours).toFixed(2) : '0.00';
  document.getElementById('hourlyRate').value = arDigits(rate + ' ' + (state.editingShift.currency || 'ج.م'));
}

document.getElementById('shiftName').addEventListener('input', e => { state.editingShift.name = e.target.value; });
document.getElementById('shiftAbbr').addEventListener('input', e => {
  state.editingShift.abbr = e.target.value;
  document.getElementById('shiftPreview').textContent = arDigits(e.target.value);
});
document.getElementById('textSize').addEventListener('input', e => {
  state.editingShift.size = +e.target.value;
  document.getElementById('sizeVal').textContent = arDigits(e.target.value);
  document.getElementById('shiftPreview').style.fontSize = e.target.value + 'px';
});
['hours','dayIncome'].forEach(id => document.getElementById(id).addEventListener('input', updateHourlyRate));

document.querySelectorAll('.ct-tab').forEach(t => {
  t.addEventListener('click', () => {
    document.querySelectorAll('.ct-tab').forEach(x => x.classList.remove('active'));
    document.querySelectorAll('.ct-panel').forEach(x => x.classList.remove('active'));
    t.classList.add('active');
    document.querySelector('.ct-panel[data-ct="' + t.dataset.ct + '"]').classList.add('active');
  });
});

function syncEditingShiftFromForm() {
  const s = state.editingShift;
  s.start = document.getElementById('startTime').value;
  s.end = document.getElementById('endTime').value;
  s.hours = +document.getElementById('hours').value || 0;
  s.currency = document.getElementById('currency').value || 'ج.م';
  s.dayIncome = +document.getElementById('dayIncome').value || 0;
  s.overtimeRate = +document.getElementById('overtimeRate').value || 0;
  s.mealAllowance = +document.getElementById('mealAllowance').value || 0;
  s.shiftAllowance = +document.getElementById('shiftAllowance').value || 0;
  s.isAnnualLeave = document.getElementById('isAnnualLeave').checked;
  s.isAbsence = document.getElementById('isAbsence').checked;
  s.customAdditions = s.customAdditions || {};
  document.querySelectorAll('.custom-addition-input').forEach(inp => {
    s.customAdditions[inp.dataset.id] = +inp.value || 0;
  });
  s.bg = state.selectedBg;
  s.fg = state.selectedFg;
}

document.getElementById('saveShift').addEventListener('click', () => {
  if (!state.editingShift.name || !state.editingShift.name.trim()) {
    toast('الرجاء إدخال اسم الشيفت', 'error');
    return;
  }
  syncEditingShiftFromForm();
  const s = state.editingShift;
  const existing = state.shifts.findIndex(x => x.id === s.id);
  if (existing >= 0) state.shifts[existing] = s;
  else state.shifts.push(s);
  save();
  document.getElementById('shiftConfigModal').classList.remove('open');
  renderMonth(); renderShiftsList(); renderSummary();
  toast('تم حفظ الشيفت', 'success');
});
document.getElementById('cancelShift').addEventListener('click', () => document.getElementById('shiftConfigModal').classList.remove('open'));
document.getElementById('closeConfig').addEventListener('click', () => document.getElementById('shiftConfigModal').classList.remove('open'));
document.getElementById('deleteShift').addEventListener('click', () => deleteShiftAction());
document.getElementById('deleteShiftIcon').addEventListener('click', () => deleteShiftAction());
document.getElementById('duplicateShift').addEventListener('click', () => {
  syncEditingShiftFromForm();
  const copy = { ...state.editingShift, id: 'shf' + nextSeq() };
  state.shifts.push(copy);
  save(); renderShiftsList();
  document.getElementById('shiftConfigModal').classList.remove('open');
  renderMonth();
  toast('تم نسخ الشيفت', 'success');
});

function deleteShiftAction() {
  if (!state.editingShift) return;
  const usage = Object.values(state.schedule).filter(sid => sid === state.editingShift.id).length;
  const msg = usage > 0
    ? `حذف "${state.editingShift.name}"؟\n(مجدول في ${usage} يوم — ستُمسح تلقائياً)`
    : `حذف "${state.editingShift.name}"؟`;
  pgConfirm(msg).then(ok => {
    if (!ok) return;
    state.shifts = state.shifts.filter(s => s.id !== state.editingShift.id);
    Object.keys(state.schedule).forEach(k => { if (state.schedule[k] === state.editingShift.id) delete state.schedule[k]; });
    save();
    document.getElementById('shiftConfigModal').classList.remove('open');
    renderMonth(); renderShiftsList();
    toast('تم حذف الشيفت', 'success');
  });
}

/* ========== Year view ========== */
function renderYear() {
  document.querySelectorAll('.year-btn').forEach(b => b.classList.toggle('active', +b.dataset.year === yearYear));
  const grid = document.getElementById('yearGrid');
  grid.innerHTML = '';
  for (let m = 0; m < 12; m++) {
    const wrap = document.createElement('div');
    wrap.className = 'year-month';
    wrap.innerHTML = `<h3>${MONTHS[m]}</h3>`;
    const cal = document.createElement('div');
    cal.className = 'mini-cal';
    getWeekdayLabels().forEach(w => {
      const d = document.createElement('div');
      d.className = 'mini-day-header';
      d.textContent = w[0];
      cal.appendChild(d);
    });
    const first = new Date(yearYear, m, 1);
    const startDay = weekdayCol(first.getDay());
    const days = new Date(yearYear, m + 1, 0).getDate();
    for (let i = 0; i < startDay; i++) { const d = document.createElement('div'); d.className = 'mday'; cal.appendChild(d); }
    for (let day = 1; day <= days; day++) {
      const k = dateKey(yearYear, m, day);
      const s = state.shifts.find(x => x.id === state.schedule[k]);
      const d = document.createElement('div');
      d.className = 'mday';
      d.textContent = arDigits(day);
      if (s) { d.style.background = s.bg; d.style.color = s.fg; }
      cal.appendChild(d);
    }
    wrap.appendChild(cal);
    grid.appendChild(wrap);
  }
}
document.querySelectorAll('.year-btn').forEach(b => {
  b.addEventListener('click', () => { yearYear = +b.dataset.year; renderYear(); });
});

/* ========== Settings modal ========== */
document.getElementById('settingsBtn').addEventListener('click', () => {
  document.getElementById('numeralType').value = state.settings.numeralType;
  document.getElementById('fontStyle').value = state.settings.font;
  document.getElementById('weekStart').value = state.settings.weekStart || 'sat';
  document.getElementById('holidayMode').value = state.settings.holidayMode || '1_1';
  // Absence settings
  const aSet = state.absenceSettings || { absenceDayValue: 0, penaltyDayValue: 0, autoApplyToPayroll: true };
  document.getElementById('absenceDayValue').value = aSet.absenceDayValue || 0;
  document.getElementById('penaltyDayValue').value = aSet.penaltyDayValue || 0;
  document.getElementById('absenceAutoApply').checked = aSet.autoApplyToPayroll !== false;
  renderAdditionTypesList();
  if (document.getElementById('view-payroll').classList.contains('active')) calcPayroll();
  renderDeductionTypesList();
  document.getElementById('settingsModal').classList.add('open');
});
document.getElementById('absenceDayValue').addEventListener('input', e => {
  state.absenceSettings.absenceDayValue = +e.target.value || 0;
  save();
  if (document.getElementById('view-summary').classList.contains('active')) renderSummary();
  if (document.getElementById('view-payroll').classList.contains('active')) calcPayroll();
});
document.getElementById('penaltyDayValue').addEventListener('input', e => {
  state.absenceSettings.penaltyDayValue = +e.target.value || 0;
  save();
  if (document.getElementById('view-summary').classList.contains('active')) renderSummary();
  if (document.getElementById('view-payroll').classList.contains('active')) calcPayroll();
});
document.getElementById('absenceAutoApply').addEventListener('change', e => {
  state.absenceSettings.autoApplyToPayroll = e.target.checked;
  save();
  if (document.getElementById('view-summary').classList.contains('active')) renderSummary();
  if (document.getElementById('view-payroll').classList.contains('active')) calcPayroll();
});
document.getElementById('closeSettings').addEventListener('click', () => document.getElementById('settingsModal').classList.remove('open'));
document.getElementById('settingsModal').addEventListener('click', e => {
  if (e.target.id === 'settingsModal') e.target.classList.remove('open');
});
document.getElementById('numeralType').addEventListener('change', e => { state.settings.numeralType = e.target.value; save(); refreshAllViews(); });
document.getElementById('fontStyle').addEventListener('change', e => { state.settings.font = e.target.value; save(); applyFont(); });
document.getElementById('weekStart').addEventListener('change', e => {
  state.settings.weekStart = e.target.value; save();
  renderWeekdaysHeader(); refreshAllViews();
});
document.getElementById('holidayMode').addEventListener('change', e => {
  state.settings.holidayMode = e.target.value;
  save();
  renderHolidaysList();
  renderLeaveBalance();
  calcPayroll();
});

/* ========== Addition types ========== */
function renderAdditionTypesList() {
  const list = document.getElementById('additionTypesList');
  list.innerHTML = '';
  state.additionTypes.forEach(a => {
    const row = document.createElement('div');
    row.className = 'addition-row';
    const note = a.special === 'overtime'
      ? 'مبلغ إجمالي (عدد الساعات × سعر الساعة) يُضاف على المرتب'
      : (a.mode === 'perShift'
          ? 'تلقائي حسب أيام الحضور × القيمة في كل وردية'
          : 'مبلغ إجمالي يُدخل يدوياً في صفحة المرتب');
    row.innerHTML = `
      <input type="checkbox" class="add-enable" data-id="${a.id}" ${a.enabled ? 'checked' : ''} />
      <label class="addition-label">
        <div class="addition-title">${escapeHtml(a.label)}</div>
        <div class="addition-note">${note}</div>
      </label>
      <div class="addition-actions">
        <button type="button" class="add-edit" data-id="${a.id}" title="تعديل">✏️</button>
        ${a.special ? '' : `<button type="button" class="add-del" data-id="${a.id}" title="حذف">×</button>`}
      </div>`;
    list.appendChild(row);
  });
  list.querySelectorAll('.add-enable').forEach(cb => cb.addEventListener('change', () => {
    const a = state.additionTypes.find(x => x.id === cb.dataset.id);
    if (a) a.enabled = cb.checked;
    save();
    if (document.getElementById('view-payroll').classList.contains('active')) { renderPayrollAdditionsRows(); calcPayroll(); }
  }));
  list.querySelectorAll('.add-edit').forEach(btn => btn.addEventListener('click', async () => {
    const a = state.additionTypes.find(x => x.id === btn.dataset.id);
    if (!a) return;
    const result = await pgAdditionForm(a);
    if (!result) return;
    a.label = result.label; a.mode = result.mode;
    save(); renderAdditionTypesList(); renderCustomAdditionFields();
    if (document.getElementById('view-payroll').classList.contains('active')) { renderPayrollAdditionsRows(); calcPayroll(); }
  }));
  list.querySelectorAll('.add-del').forEach(btn => btn.addEventListener('click', async () => {
    const ok = await pgConfirm('حذف هذا البند من الإضافات؟');
    if (!ok) return;
    const id = btn.dataset.id;
    state.additionTypes = state.additionTypes.filter(x => x.id !== id);
    state.shifts.forEach(s => { if (s.customAdditions) delete s.customAdditions[id]; });
    if (state.payRange.manualAdditions) delete state.payRange.manualAdditions[id];
    save(); renderAdditionTypesList(); renderCustomAdditionFields();
    if (document.getElementById('view-payroll').classList.contains('active')) { renderPayrollAdditionsRows(); calcPayroll(); }
  }));
}

document.getElementById('addAdditionType').addEventListener('click', async () => {
  const result = await pgAdditionForm(null);
  if (!result) return;
  state.additionTypes.push({
    id: 'cadd' + nextSeq(), label: result.label, mode: result.mode, enabled: true, special: null
  });
  save(); renderAdditionTypesList(); renderCustomAdditionFields();
  if (document.getElementById('view-payroll').classList.contains('active')) { renderPayrollAdditionsRows(); calcPayroll(); }
});

/* ========== Deduction types ========== */
function renderDeductionTypesList() {
  const list = document.getElementById('deductionTypesList');
  list.innerHTML = '';
  if (state.deductionTypes.length === 0) {
    list.innerHTML = '<div style="color:var(--text-muted);font-size:13px;padding:6px 0">لا يوجد بنود خصم بعد</div>';
    return;
  }
  state.deductionTypes.forEach(dt => {
    const row = document.createElement('div');
    row.className = 'ded-type-item';
    row.innerHTML = `
      <div class="info">
        <div class="nm">${escapeHtml(dt.label)}</div>
        <div class="sub">${dt.unit === 'hours' ? 'ساعات × متوسط أجر الساعة' : 'مبلغ ثابت'}</div>
      </div>
      <button class="del" type="button" data-id="${dt.id}">×</button>`;
    list.appendChild(row);
  });
  list.querySelectorAll('.del').forEach(btn => btn.addEventListener('click', () => {
    state.deductionTypes = state.deductionTypes.filter(x => x.id !== btn.dataset.id);
    save(); renderDeductionTypesList();
    if (document.getElementById('view-payroll').classList.contains('active')) renderDeductionsRows();
  }));
}

document.getElementById('addDedType').addEventListener('click', () => {
  const labelInput = document.getElementById('newDedLabel');
  const label = labelInput.value.trim();
  if (!label) { toast('اكتب اسم البند أولاً', 'error'); return; }
  const unit = document.getElementById('newDedUnit').value;
  state.deductionTypes.push({ id: 'ded' + nextSeq(), label, unit });
  save(); labelInput.value = ''; renderDeductionTypesList();
  if (document.getElementById('view-payroll').classList.contains('active')) renderDeductionsRows();
});

/* ========== Summary view ========== */
document.querySelectorAll('.st-tab').forEach(t => {
  t.addEventListener('click', () => {
    document.querySelectorAll('.st-tab').forEach(x => x.classList.remove('active'));
    t.classList.add('active');
    state.summaryMode = t.dataset.st;
    document.getElementById('rangePickers').classList.toggle('hidden', t.dataset.st !== 'range');
    document.getElementById('periodLabel').textContent = arDigits(
      t.dataset.st === 'year' ? yearYear : `${MONTHS[state.current.month]} ${state.current.year}`
    );
    renderSummary();
  });
});

document.getElementById('prevPeriod').addEventListener('click', () => {
  if (state.summaryMode === 'month') {
    state.current.month--;
    if (state.current.month < 0) { state.current.month = 11; state.current.year--; }
  } else if (state.summaryMode === 'year') { yearYear--; }
  renderSummary(); updateStaticLabels();
});
document.getElementById('nextPeriod').addEventListener('click', () => {
  if (state.summaryMode === 'month') {
    state.current.month++;
    if (state.current.month > 11) { state.current.month = 0; state.current.year++; }
  } else if (state.summaryMode === 'year') { yearYear++; }
  renderSummary(); updateStaticLabels();
});

function getSummaryPeriodRange() {
  let from, to;
  if (state.summaryMode === 'month') {
    from = new Date(state.current.year, state.current.month, 1);
    to = new Date(state.current.year, state.current.month + 1, 0);
  } else if (state.summaryMode === 'year') {
    from = new Date(yearYear, 0, 1); to = new Date(yearYear, 11, 31);
  } else {
    from = new Date(state.range.from); to = new Date(state.range.to);
  }
  return {
    fromKey: dateKey(from.getFullYear(), from.getMonth(), from.getDate()),
    toKey: dateKey(to.getFullYear(), to.getMonth(), to.getDate())
  };
}

function getActiveShifts() {
  let from, to;
  if (state.summaryMode === 'month') {
    from = new Date(state.current.year, state.current.month, 1);
    to = new Date(state.current.year, state.current.month + 1, 0);
  } else if (state.summaryMode === 'year') {
    from = new Date(yearYear, 0, 1); to = new Date(yearYear, 11, 31);
  } else {
    from = new Date(state.range.from); to = new Date(state.range.to);
  }
  const result = [];
  for (let d = new Date(from); d <= to; d.setDate(d.getDate() + 1)) {
    const k = dateKey(d.getFullYear(), d.getMonth(), d.getDate());
    const sid = state.schedule[k];
    if (sid) {
      const s = state.shifts.find(x => x.id === sid);
      if (s) result.push({ date: k, shift: s });
    }
  }
  return result;
}

function renderSummary() {
  const data = getActiveShifts();
  const body = document.getElementById('statsBody');
  body.innerHTML = '';
  const groups = {};
  data.forEach(({ shift }) => {
    if (!groups[shift.id]) groups[shift.id] = { shift, count: 0, hours: 0, income: 0 };
    groups[shift.id].count++;
    groups[shift.id].hours += (shift.hours || 0);
    groups[shift.id].income += (shift.dayIncome || 0);
  });
  let totalCount = 0, totalHours = 0, totalIncome = 0;
  const groupArr = Object.values(groups).sort((a, b) => b.income - a.income);
  if (groupArr.length === 0) {
    body.innerHTML = '<div class="mini-list-empty">لا توجد شيفتات في هذه الفترة</div>';
  } else {
    groupArr.forEach(g => {
      totalCount += g.count; totalHours += g.hours; totalIncome += g.income;
      const row = document.createElement('div');
      row.className = 'stats-row';
      row.innerHTML = `
        <div class="name">
          <span class="nm">${escapeHtml(g.shift.name)}</span>
          <span class="sub">(${arDigits(pad(g.shift.start))}-${arDigits(pad(g.shift.end))})</span>
        </div>
        <div>${arDigits(g.count)}</div>
        <div>${arDigits(g.hours)}h<br><span style="color:var(--text-muted)">${arDigits(g.income.toFixed(2))}</span></div>
        <div class="check"><span>✓</span></div>`;
      body.appendChild(row);
    });
  }
  const global = document.getElementById('statsGlobal');
  global.innerHTML = `الإجمالي: ${arDigits(totalCount)} شيفت<br>${arDigits(totalHours)} ساعة<br>${arDigits(totalIncome.toFixed(2))} ${state.shifts[0]?.currency || 'ج.م'}`;
  renderLeaveBalance();
  renderHolidaysList();
  renderAbsenceSummary();
}

function renderLeaveBalance() {
  if (document.activeElement?.id !== 'sumLeavePrev') {
    document.getElementById('sumLeavePrev').value = state.leaveBalance.previous;
  }
  if (document.activeElement?.id !== 'sumLeaveAccrued') {
    document.getElementById('sumLeaveAccrued').value = state.leaveBalance.accrued;
  }
  const { fromKey, toKey } = getSummaryPeriodRange();
  const leaveDatesInPeriod = Object.entries(state.schedule)
    .filter(([date, sid]) => {
      if (date < fromKey || date > toKey) return false;
      const s = state.shifts.find(x => x.id === sid);
      return !!(s && s.isAnnualLeave);
    })
    .map(([date, sid]) => ({ date, shift: state.shifts.find(x => x.id === sid) }))
    .sort((a, b) => a.date.localeCompare(b.date));
  const used = leaveDatesInPeriod.length;
  const holidayCompBalance = state.holidays
    .filter(h => h.date >= fromKey && h.date <= toKey)
    .reduce((sum, h) => sum + computeHolidayLeaveBalance(h), 0);
  document.getElementById('sumHolidayCompBalance').value = arDigits(holidayCompBalance);
  const remaining = (+state.leaveBalance.previous || 0) + (+state.leaveBalance.accrued || 0) - used;
  document.getElementById('sumLeaveUsed').value = arDigits(used);
  document.getElementById('sumLeaveRemaining').value = arDigits(remaining);
  const list = document.getElementById('leaveDatesList');
  list.innerHTML = '';
  if (leaveDatesInPeriod.length === 0) {
    list.innerHTML = '<div class="mini-list-empty">لا يوجد أيام إجازة اعتيادية مجدولة في هذه الفترة</div>';
  } else {
    leaveDatesInPeriod.forEach(({ date, shift }) => {
      const item = document.createElement('div');
      item.className = 'mini-list-item';
      item.innerHTML = `
        <div class="mli-info">
          <span class="mli-name">${arDigits(formatDateDisplay(date))}</span>
          <span class="mli-sub">${escapeHtml(shift?.name || '')}</span>
        </div>`;
      list.appendChild(item);
    });
  }
}

document.getElementById('sumLeavePrev').addEventListener('change', e => { state.leaveBalance.previous = +e.target.value || 0; save(); renderLeaveBalance(); });
document.getElementById('sumLeaveAccrued').addEventListener('change', e => { state.leaveBalance.accrued = +e.target.value || 0; save(); renderLeaveBalance(); });

document.getElementById('leaveDatesToggle').addEventListener('click', () => {
  const list = document.getElementById('leaveDatesList');
  const arrow = document.getElementById('leaveDatesArrow');
  const collapsed = list.style.display === 'none';
  list.style.display = collapsed ? '' : 'none';
  arrow.classList.toggle('collapsed', !collapsed);
});

document.getElementById('holidaysToggle').addEventListener('click', () => {
  const list = document.getElementById('holidaysList');
  const arrow = document.getElementById('holidaysArrow');
  const collapsed = list.style.display === 'none';
  list.style.display = collapsed ? '' : 'none';
  arrow.classList.toggle('collapsed', !collapsed);
});

function renderHolidaysList() {
  const list = document.getElementById('holidaysList');
  list.innerHTML = '';
  if (state.holidays.length === 0) {
    list.innerHTML = '<div class="mini-list-empty">لا يوجد عطلات رسمية مسجلة</div>';
    return;
  }
  [...state.holidays].sort((a, b) => (a.date || '').localeCompare(b.date || '')).forEach(h => {
    const item = document.createElement('div');
    item.className = 'mini-list-item';
    const scheduledShiftId = h.date ? state.schedule[h.date] : null;
    const scheduledShift = scheduledShiftId ? state.shifts.find(x => x.id === scheduledShiftId) : null;
    const sub = [
      h.date ? arDigits(formatDateDisplay(h.date)) : '',
      'الرصيد: ' + arDigits(h.balance || 1) + ' يوم',
      h.leaveDate ? 'تاريخ الإجازة: ' + arDigits(formatDateDisplay(h.leaveDate)) : '',
      scheduledShift ? '⏰ تم العمل (وردية ' + escapeHtml(scheduledShift.name) + ')' : ''
    ].filter(Boolean).join(' · ');
    item.innerHTML = `
      <div class="mli-info">
        <span class="mli-name">${escapeHtml(h.name)}</span>
        <span class="mli-sub">${sub}</span>
      </div>
      <button class="mli-del" type="button" data-id="${h.id}">×</button>`;
    list.appendChild(item);
  });
  list.querySelectorAll('.mli-del').forEach(btn => btn.addEventListener('click', () => {
    state.holidays = state.holidays.filter(h => h.id !== btn.dataset.id);
    save();
    renderHolidaysList();
    renderLeaveBalance();
    if (document.getElementById('view-payroll').classList.contains('active')) calcPayroll();
  }));
  list.querySelectorAll('.holiday-leave-input').forEach(inp => {
    inp.addEventListener('change', () => {
      const h = state.holidays.find(x => x.id === inp.dataset.id);
      if (!h) return;
      h.leaveDates = Array.isArray(h.leaveDates) ? h.leaveDates : [];
      h.leaveDates[+inp.dataset.idx] = inp.value;
      save();
    });
  });
}

function addDaysToDateStr(dateStr, n) {
  const d = new Date(dateStr + 'T00:00:00');
  d.setDate(d.getDate() + n);
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}

// "طريقة حساب العطلة الرسمية" is stored as "incomeDays_leaveDays" (e.g. "1_1" =
// يوم إجازة + يوم دخل). This parses it into { income, leave }.
function getHolidayDayCounts() {
  const raw = state.settings.holidayMode || '1_1';
  const [income, leave] = String(raw).split('_').map(n => +n || 0);
  return { income, leave };
}

// The leave-day credit for a holiday: 0 if the employee rested (no shift scheduled
// on the holiday's date), otherwise the "leave days" configured in the "طريقة حساب
// العطلة الرسمية" setting.
function computeHolidayLeaveBalance(h) {
  const worked = !!(h.date && state.schedule[h.date]);
  return worked ? getHolidayDayCounts().leave : 0;
}

document.getElementById('newHolidayName').addEventListener('change', e => {
  document.getElementById('row-customHolidayName').style.display = e.target.value === '__other__' ? '' : 'none';
});
/* ============================================================
   Absence summary (Statistics page)
   ============================================================ */
function renderAbsenceSummary() {
  const { fromKey, toKey } = getSummaryPeriodRange();
  const dates = Object.entries(state.schedule)
    .filter(([date, sid]) => {
      if (date < fromKey || date > toKey) return false;
      const s = state.shifts.find(x => x.id === sid);
      return !!(s && s.isAbsence);
    })
    .map(([date]) => date)
    .sort();

  const result = computeAbsencePenalty(dates);
  const aSet = state.absenceSettings || { absenceDayValue: 0, penaltyDayValue: 0, autoApplyToPayroll: true };
  const absenceValue = (+aSet.absenceDayValue) || 0;
  const penaltyValue = (+aSet.penaltyDayValue) || 0;
  const totalDeduction = (result.totalDays * absenceValue) + (result.totalPenaltyDays * penaltyValue);
  const cur = state.shifts[0]?.currency || 'ج.م';

  const totalEl = document.getElementById('absenceTotalDays');
  const penaltyEl = document.getElementById('absencePenaltyDays');
  const valueEl = document.getElementById('absenceTotalValue');
  if (totalEl) totalEl.value = arDigits(result.totalDays);
  if (penaltyEl) penaltyEl.value = arDigits(result.totalPenaltyDays);
  if (valueEl) valueEl.value = arDigits(totalDeduction.toFixed(2) + ' ' + cur);

  const spellsEl = document.getElementById('absenceSpellsList');
  if (spellsEl) {
    spellsEl.innerHTML = '';
    if (result.spells.length === 0) {
      spellsEl.innerHTML = '<div class="mini-list-empty">لا يوجد أيام غياب في هذه الفترة</div>';
    } else {
      result.spells.forEach((sp, idx) => {
        const item = document.createElement('div');
        item.className = 'mini-list-item';
        const range = sp.days === 1
          ? arDigits(formatDateDisplay(sp.start))
          : arDigits(formatDateDisplay(sp.start)) + ' ← ' + arDigits(formatDateDisplay(sp.end));
        const breakdown = sp.dates.map((d, i) =>
          `<span style="background:var(--bg-4);padding:2px 6px;border-radius:4px;font-size:11px">يوم ${arDigits(i + 1)}: ${arDigits(penaltyForDay(i))} ج</span>`
        ).join(' ');
        item.innerHTML = `
          <div class="mli-info" style="flex:1">
            <span class="mli-name">📅 فترة غياب #${arDigits(idx + 1)}: ${range} (${arDigits(sp.days)} يوم)</span>
            <span class="mli-sub">جزاء: ${arDigits(sp.penaltyDays)} يوم</span>
            <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:4px">${breakdown}</div>
          </div>
        `;
        spellsEl.appendChild(item);
      });
    }
  }
}

/* ============================================================
   Auto-apply absence deduction to the payroll view
   ============================================================ */
function computeAbsenceDeductionForRange(from, to) {
  const dates = Object.entries(state.schedule)
    .filter(([date, sid]) => {
      if (date < from || date > to) return false;
      const s = state.shifts.find(x => x.id === sid);
      return !!(s && s.isAbsence);
    })
    .map(([date]) => date)
    .sort();
  const result = computeAbsencePenalty(dates);
  const aSet = state.absenceSettings || { absenceDayValue: 0, penaltyDayValue: 0, autoApplyToPayroll: true };
  if (!aSet.autoApplyToPayroll) return { ...result, deduction: 0 };
  const absenceValue = (+aSet.absenceDayValue) || 0;
  const penaltyValue = (+aSet.penaltyDayValue) || 0;
  const deduction = (result.totalDays * absenceValue) + (result.totalPenaltyDays * penaltyValue);
  return { ...result, deduction };
}

document.getElementById('addHoliday').addEventListener('click', () => {
  const selectVal = document.getElementById('newHolidayName').value;
  const baseName = selectVal === '__other__' ? document.getElementById('newHolidayNameCustom').value.trim() : selectVal;
  const startDate = document.getElementById('newHolidayDate').value;
  const days = Math.max(1, +document.getElementById('newHolidayDays').value || 1);
  if (!baseName || !startDate) { toast('الرجاء اختيار اسم وتاريخ العطلة', 'error'); return; }
  for (let i = 0; i < days; i++) {
    const entryName = days > 1 ? `${baseName} ${arDigits(i + 1)}` : baseName;
    state.holidays.push({
      id: 'hol' + nextSeq(),
      name: entryName,
      date: addDaysToDateStr(startDate, i),
      leaveDates: []
    });
  }
  save();
  document.getElementById('newHolidayName').value = '';
  document.getElementById('newHolidayNameCustom').value = '';
  document.getElementById('row-customHolidayName').style.display = 'none';
  document.getElementById('newHolidayDate').value = '';
  document.getElementById('newHolidayDays').value = '1';
  renderHolidaysList();
  renderLeaveBalance();
  if (document.getElementById('view-payroll').classList.contains('active')) calcPayroll();
  toast('تمت إضافة العطلة', 'success');
});

function syncDateDisplay(inputId, displayId) {
  document.getElementById(displayId).textContent = formatDateDisplay(document.getElementById(inputId).value);
}
function syncAllDateDisplays() {
  syncDateDisplay('fromDate', 'fromDateDisplay');
  syncDateDisplay('toDate', 'toDateDisplay');
  syncDateDisplay('payFrom', 'payFromDisplay');
  syncDateDisplay('payTo', 'payToDisplay');
}
document.getElementById('fromDate').addEventListener('change', e => { state.range.from = e.target.value; save(); syncDateDisplay('fromDate', 'fromDateDisplay'); renderSummary(); });
document.getElementById('toDate').addEventListener('change', e => { state.range.to = e.target.value; save(); syncDateDisplay('toDate', 'toDateDisplay'); renderSummary(); });

/* ========== Payroll view ========== */
function renderDeductionsRows() {
  const container = document.getElementById('deductionsRows');
  const preserved = {};
  state.deductionTypes.forEach(dt => {
    const el = document.getElementById('ded_' + dt.id);
    if (el) preserved[dt.id] = el.value;
  });
  container.innerHTML = '';
  if (state.deductionTypes.length === 0) {
    container.innerHTML = '<div class="mini-list-empty">لا يوجد بنود خصم — أضفها من الإعدادات</div>';
    return;
  }
  state.deductionTypes.forEach(dt => {
    const isHours = dt.unit === 'hours';
    const row = document.createElement('div');
    row.className = 'row';
    row.innerHTML = `
      <label>${escapeHtml(dt.label)}${isHours ? ' (ساعات × متوسط أجر الساعة)' : ''}</label>
      <div class="inline">
        <input type="number" id="ded_${dt.id}" value="${preserved[dt.id] !== undefined ? escapeHtml(preserved[dt.id]) : '0'}" min="0" step="${isHours ? '0.5' : '0.01'}" />
        <span>${isHours ? 'ساعة' : 'ج.م'}</span>
      </div>`;
    container.appendChild(row);
    document.getElementById('ded_' + dt.id).addEventListener('input', () => calcPayroll());
  });
}

function initSummaryRangeDefaults() {
  if (!state.range.from || !state.range.to) {
    const y = state.current.year, m = state.current.month;
    state.range.from = dateKey(y, m, 1);
    state.range.to = dateKey(y, m, new Date(y, m + 1, 0).getDate());
    save();
  }
  document.getElementById('fromDate').value = state.range.from;
  document.getElementById('toDate').value = state.range.to;
  syncDateDisplay('fromDate', 'fromDateDisplay');
  syncDateDisplay('toDate', 'toDateDisplay');
}

function initPayroll() {
  const y = state.current.year, m = state.current.month;
  const defaultFrom = dateKey(y, m, 1);
  const defaultTo = dateKey(y, m, new Date(y, m + 1, 0).getDate());
  if (state.payRange.from && state.payRange.to) {
    document.getElementById('payFrom').value = state.payRange.from;
    document.getElementById('payTo').value = state.payRange.to;
  } else {
    document.getElementById('payFrom').value = defaultFrom;
    document.getElementById('payTo').value = defaultTo;
    state.payRange.from = defaultFrom;
    state.payRange.to = defaultTo;
    save();
  }
  if (!state.range.from || !state.range.to) {
    state.range.from = defaultFrom;
    state.range.to = defaultTo;
    save();
  }
  document.getElementById('fromDate').value = state.range.from;
  document.getElementById('toDate').value = state.range.to;
  syncAllDateDisplays();
  renderPayrollAdditionsRows();
  renderDeductionsRows();
  calcPayroll();
}

function renderPayrollAdditionsRows() {
  const container = document.getElementById('additionsIncomeRows');
  if (!container) return;
  container.innerHTML = '';
  const enabledTypes = state.additionTypes.filter(a => a.enabled);
  if (enabledTypes.length === 0) {
    container.innerHTML = '<div class="mini-list-empty">لا توجد إضافات مفعّلة — فعّلها من الإعدادات</div>';
    return;
  }
  enabledTypes.forEach(a => {
    const row = document.createElement('div');
    row.className = 'row';
    row.id = 'row-add-' + a.id;
    if (a.special === 'overtime') {
      row.innerHTML = `
        <label>${escapeHtml(a.label)} (ساعات × سعر)</label>
        <div class="inline">
          <input type="number" id="overtimeHoursTotal" value="${state.payRange.overtimeHours || 0}" min="0" step="0.5" placeholder="ساعات" />
          <span>ساعة</span>
          <input type="text" id="totalOvertime" readonly value="0.00 ج.م" />
        </div>`;
    } else if (a.mode === 'perShift') {
      row.innerHTML = `
        <label>${escapeHtml(a.label)} (تلقائي: أيام × قيمة البدل)</label>
        <input type="text" id="addTotal_${a.id}" readonly value="0.00 ج.م" />`;
    } else {
      const savedVal = (state.payRange.manualAdditions && state.payRange.manualAdditions[a.id]) || 0;
      row.innerHTML = `
        <label>${escapeHtml(a.label)} (مبلغ إجمالي)</label>
        <input type="number" id="addManual_${a.id}" value="${savedVal}" min="0" step="0.01" placeholder="القيمة" />`;
    }
    container.appendChild(row);
  });
  const overtimeHoursEl = document.getElementById('overtimeHoursTotal');
  if (overtimeHoursEl) {
    overtimeHoursEl.addEventListener('change', e => {
      state.payRange.overtimeHours = +e.target.value || 0; save(); calcPayroll();
    });
  }
  container.querySelectorAll('input[id^="addManual_"]').forEach(inp => {
    inp.addEventListener('change', e => {
      const id = inp.id.replace('addManual_', '');
      state.payRange.manualAdditions = state.payRange.manualAdditions || {};
      state.payRange.manualAdditions[id] = +e.target.value || 0;
      save(); calcPayroll();
    });
  });
}

document.getElementById('payFrom').addEventListener('change', e => { state.payRange.from = e.target.value; save(); syncDateDisplay('payFrom', 'payFromDisplay'); calcPayroll(); });
document.getElementById('payTo').addEventListener('change', e => { state.payRange.to = e.target.value; save(); syncDateDisplay('payTo', 'payToDisplay'); calcPayroll(); });
document.getElementById('holidayMode').addEventListener('change', () => calcPayroll());
document.getElementById('calcPayroll').addEventListener('click', () => calcPayroll());

function calcPayroll() {
  const from = document.getElementById('payFrom').value;
  const to = document.getElementById('payTo').value;
  if (!from || !to) return;
  const fromD = new Date(from), toD = new Date(to);
  if (fromD > toD) { toast('التاريخ "من" يجب أن يكون قبل "إلى"', 'error'); return; }

  let totalDaysIncome = 0;
  const shiftCounts = {};
  for (let d = new Date(fromD); d <= toD; d.setDate(d.getDate() + 1)) {
    const k = dateKey(d.getFullYear(), d.getMonth(), d.getDate());
    const sid = state.schedule[k];
    if (sid) {
      const s = state.shifts.find(x => x.id === sid);
      if (s) {
        totalDaysIncome += (+s.dayIncome || 0);
        shiftCounts[s.id] = (shiftCounts[s.id] || 0) + 1;
      }
    }
  }
  const cur = state.shifts[0]?.currency || 'ج.م';
  // holidayMode is configured in Settings as "incomeDays_leaveDays"
  const { income: hIncomeDays } = getHolidayDayCounts();
  const holidaysInPeriod = state.holidays.filter(h => h.date >= from && h.date <= to);
  const hCount = holidaysInPeriod.length;
  const hcEl = document.getElementById('holidayCount');
  if (hcEl) hcEl.value = arDigits(hCount);
  const totalDays = Object.values(shiftCounts).reduce((a, b) => a + b, 0);
  const avgDay = totalDays > 0 ? totalDaysIncome / totalDays : 0;
  const holidayAllowance = holidaysInPeriod.reduce((sum, h) => {
    const sid = state.schedule[h.date];
    const scheduledShift = sid ? state.shifts.find(x => x.id === sid) : null;
    const dayValue = scheduledShift ? (+scheduledShift.dayIncome || 0) : avgDay;
    return sum + (dayValue * hIncomeDays);
  }, 0);

  let additionsTotal = 0;
  state.additionTypes.forEach(a => {
    if (!a.enabled) return;
    if (a.special === 'overtime') {
      const hoursEl = document.getElementById('overtimeHoursTotal');
      const overtimeInput = +(hoursEl?.value || 0);
      const rates = state.shifts.map(s => +s.overtimeRate || 0).filter(r => r > 0);
      const avgOvertimeRate = rates.length > 0 ? rates.reduce((x, y) => x + y, 0) / rates.length : 0;
      const total = overtimeInput * avgOvertimeRate;
      const totalEl = document.getElementById('totalOvertime');
      if (totalEl) totalEl.value = arDigits(total.toFixed(2) + ' ' + cur);
      additionsTotal += total;
    } else if (a.mode === 'perShift') {
      const valueKey = a.special === 'shiftAllowance' ? 'shiftAllowance' : a.special === 'mealAllowance' ? 'mealAllowance' : null;
      const total = Object.entries(shiftCounts).reduce((sum, [id, c]) => {
        const s = state.shifts.find(x => x.id === id);
        if (!s) return sum;
        const perDay = valueKey ? (+s[valueKey] || 0) : (+(s.customAdditions?.[a.id]) || 0);
        return sum + (c * perDay);
      }, 0);
      const totalEl = document.getElementById('addTotal_' + a.id);
      if (totalEl) totalEl.value = arDigits(total.toFixed(2) + ' ' + cur);
      additionsTotal += total;
    } else {
      const el = document.getElementById('addManual_' + a.id);
      const val = el ? (+el.value || 0) : ((state.payRange.manualAdditions && state.payRange.manualAdditions[a.id]) || 0);
      additionsTotal += val;
    }
  });

  const totalIncome = totalDaysIncome + additionsTotal + holidayAllowance;
  document.getElementById('totalDaysIncome').value = arDigits(totalDaysIncome.toFixed(2) + ' ' + cur);
  const haEl = document.getElementById('holidayAllowance');
  if (haEl) haEl.value = arDigits(holidayAllowance.toFixed(2) + ' ' + cur);
  document.getElementById('totalIncome').value = arDigits(totalIncome.toFixed(2) + ' ' + cur);

  const avgHourly = (() => {
    const totalH = Object.entries(shiftCounts).reduce((sum, [id, c]) => {
      const s = state.shifts.find(x => x.id === id);
      return sum + ((+s.hours || 0) * c);
    }, 0);
    return totalH > 0 ? totalDaysIncome / totalH : 0;
  })();
  const customDeductionsTotal = state.deductionTypes.reduce((sum, dt) => {
    const el = document.getElementById('ded_' + dt.id);
    const val = el ? (+el.value || 0) : 0;
    return sum + (dt.unit === 'hours' ? val * avgHourly : val);
  }, 0);
  // Absence deduction (auto from calendar + Settings)
  const absenceInfo = computeAbsenceDeductionForRange(from, to);
  const absenceTotalEl = document.getElementById('absenceDeduction');
  if (absenceTotalEl) {
    const auto = state.absenceSettings && state.absenceSettings.autoApplyToPayroll;
    absenceTotalEl.value = arDigits(
      (auto ? absenceInfo.deduction : 0).toFixed(2) + ' ' + cur
    );
  }
  const absenceDeductionTotal = (state.absenceSettings && state.absenceSettings.autoApplyToPayroll)
    ? absenceInfo.deduction : 0;
  const totalDeductions = customDeductionsTotal + absenceDeductionTotal;
  document.getElementById('totalDeductions').value = arDigits(totalDeductions.toFixed(2) + ' ' + (state.shifts[0]?.currency || 'ج.م'));
  const net = totalIncome - totalDeductions;
  document.getElementById('netIncome').textContent = arDigits(totalIncome.toFixed(2) + ' ' + cur);
  document.getElementById('netDeductions').textContent = arDigits(totalDeductions.toFixed(2) + ' ' + cur);
  document.getElementById('netSalary').textContent = arDigits(net.toFixed(2) + ' ' + cur);
}

/* ========== Company selector ========== */
function renderCompanySelect() {
  const sel = document.getElementById('companySelect');
  sel.innerHTML = state.companies.map((c, i) => `<option value="${i}">${escapeHtml(c)}</option>`).join('');
  sel.value = state.currentCompanyIndex;
}
document.getElementById('companySelect').addEventListener('change', e => { state.currentCompanyIndex = +e.target.value; save(); });
document.getElementById('editCompanyBtn').addEventListener('click', async () => {
  const current = state.companies[state.currentCompanyIndex] || '';
  const name = await pgPrompt('اسم الشركة', current);
  if (name === null || name === '') return;
  state.companies[state.currentCompanyIndex] = name;
  save(); renderCompanySelect();
  toast('تم تحديث اسم الشركة', 'success');
});

/* ========== Side menu ========== */
document.getElementById('menuBtn').addEventListener('click', () => {
  document.getElementById('calendarViewSelect').value = state.settings.calendarView || 'grid';
  document.getElementById('sideMenuOverlay').classList.add('open');
});
document.getElementById('closeSideMenu').addEventListener('click', () => document.getElementById('sideMenuOverlay').classList.remove('open'));
document.getElementById('sideMenuOverlay').addEventListener('click', e => {
  if (e.target.id === 'sideMenuOverlay') e.target.classList.remove('open');
});
document.getElementById('calendarViewSelect').addEventListener('change', e => {
  state.settings.calendarView = e.target.value; save(); renderMonth();
});

document.getElementById('menuExport').addEventListener('click', () => {
  const data = JSON.stringify({
    shifts: state.shifts, schedule: state.schedule,
    settings: state.settings, additionTypes: state.additionTypes,
    deductionTypes: state.deductionTypes, range: state.range, payRange: state.payRange,
    companies: state.companies, currentCompanyIndex: state.currentCompanyIndex,
    leaveBalance: state.leaveBalance, holidays: state.holidays
  }, null, 2);
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'shifter-backup-' + dateKey(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()) + '.json';
  a.click();
  URL.revokeObjectURL(url);
  document.getElementById('sideMenuOverlay').classList.remove('open');
  toast('تم تنزيل ملف البيانات', 'success');
});

document.getElementById('menuImport').addEventListener('click', () => {
  document.getElementById('sideMenuOverlay').classList.remove('open');
  document.getElementById('importFile').click();
});

document.getElementById('menuReset').addEventListener('click', () => {
  document.getElementById('sideMenuOverlay').classList.remove('open');
  pgConfirm('سيتم مسح كل البيانات (شيفتات، جداول، إجازات، عطلات). متأكد؟').then(ok => {
    if (!ok) return;
    _removeItem(STORAGE_KEY);
    location.reload();
  });
});

/* ========== Refresh all views ========== */
function refreshAllViews() {
  renderMonth();
  syncAllDateDisplays();
  if (document.getElementById('view-year').classList.contains('active')) renderYear();
  if (document.getElementById('view-summary').classList.contains('active')) renderSummary();
  if (document.getElementById('view-payroll').classList.contains('active')) calcPayroll();
}

/* ========== Init ========== */
load();
renderCompanySelect();
document.querySelector('main').classList.add('no-scroll');
renderWeekdaysHeader();
renderMonth();
